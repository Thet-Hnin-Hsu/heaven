<?php
	session_start();
	error_reporting(0);
	include('includes/dbconnection.php');

    $uid=$_SESSION['uid'];

	if (strlen($_SESSION['uid']==0)) {
		header('location:logout.php');
	} else {
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Heaven Restaurant - Order History</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <link href="assets/img/logo.png" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Nunito:wght@600;700;800&family=Pacifico&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="assets/lib/animate/animate.min.css" rel="stylesheet">
    <link href="assets/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="assets/lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="assets/css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Navbar & Hero Start -->
        <div class="container-xxl position-relative p-0">
            <!-- header start -->
            <?php include_once('includes/header.php');?>
            <!-- header end -->

            <div class="container-xxl py-5 bg-dark hero-header mb-5">
                <div class="container text-center my-5 pt-5 pb-4">
                    <h1 class="display-3 text-white mb-3 animated slideInDown">Order History</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center text-uppercase">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item"><a href="#">Pages</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">Order History</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Navbar & Hero End -->


        <!-- Order History Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="text-center wow fadeInUp mb-5" data-wow-delay="0.1s">
                    <h5 class="section-title ff-secondary text-center text-primary fw-normal">Order History</h5>
                </div>

                <div class="row g-4">
                    <div class="col-lg-10 offset-lg-1">
                        <div class="wow fadeInUp" data-wow-delay="0.2s">
                            <table class="border-0">
                                <thead class="border-bottom border-bottom-secondary">
                                    <tr>
                                        <th width="300px" height="50px" class="text-center">#</th>
                                        <th width="300px" height="50px" class="text-center">Menu Image</th> 
									    <th width="300px" height="50px" class="text-center">Menu Name</th> 
									    <th width="300px" height="50px" class="text-center">Order Number</th> 
                                        <th width="300px" height="50px" class="text-center">Action</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php
                                        $ret=mysqli_query($con,"select menu.id as mid, menu.menu_image,menu.menu_name,menu.menu_price,orders.id as bid,orders.order_phone,orders.order_address,orders.order_number,orders.order_date from orders join menu on menu.id=orders.menu_id where orders.user_id='$uid' ");
                                        $cnt=1;
                                        while($row=mysqli_fetch_array($ret)) { ?>
                                            <tr class="border-bottom border-bottom-warning"> 
                                                <td width="300px" height="70px" class="text-center"><?php echo $cnt;?></td>
                                                <td width="300px" height="70px" class="text-center"><img src="admin/images/<?php echo $row['menu_image']?>" width="50" height="50px"></td>
                                                <td width="300px" height="70px" class="text-center"><?php  echo $row['menu_name'];?></td>
                                                <td width="300px" height="70px" class="text-center"><?php  echo $row['order_number'];?></td>
                                                <td width="300px" height="70px" class="text-center">
                                                    <a href="order-detail.php?ordnum=<?php echo $row['order_number'];?>" class="btn btn-primary">View</a>
                                                </td> 
                                            </tr> 
                                    <?php $cnt=$cnt+1; } ?>
							    </tbody> 
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Order History End -->

        <!-- Footer Start -->
        <?php include_once('includes/footer.php');?>
        <!-- Footer End -->
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/lib/wow/wow.min.js"></script>
    <script src="assets/lib/easing/easing.min.js"></script>
    <script src="assets/lib/waypoints/waypoints.min.js"></script>
    <script src="assets/lib/counterup/counterup.min.js"></script>
    <script src="assets/lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="assets/lib/tempusdominus/js/moment.min.js"></script>
    <script src="assets/lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="assets/lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- disable body scroll which navbar is in active -->
    <script>
        $(function () {
            $('.navbar-toggler').click(function () {
                $('body').toggleClass('noscroll');
            })
        });
    </script>

    <!-- Template Javascript -->
    <script src="assets/js/main.js"></script>
</body>

</html>

<?php } ?>