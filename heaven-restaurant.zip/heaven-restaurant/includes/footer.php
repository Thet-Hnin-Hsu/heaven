<!-- Footer Start -->
<div class="container-fluid bg-dark text-light footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s">
  <div class="container py-5">
    <div class="row g-5">
      <div class="col-lg-3 col-md-6">
        <h4 class="section-title ff-secondary text-start text-primary fw-normal mb-4">Company</h4>
        
        <a class="btn btn-link" href="#about-id">About Us</a>

        <a class="btn btn-link" href="contact.php">Contact Us</a>

        <a class="btn btn-link" href="#team-id">Our Team</a>

        <a class="btn btn-link" href="#testimonial-id">Testimonial</a>
      </div>

      <div class="col-lg-3 col-md-6">
        <h4 class="section-title ff-secondary text-start text-primary fw-normal mb-4">Contact</h4>

        <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>No.49, Inyar Road, Yangon</p>

        <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+959 783 676 736</p>

        <p class="mb-2"><i class="fa fa-envelope me-3"></i>heaven.restaurant@pmojt.com</p>

        <div class="d-flex justify-content-evenly pt-2">
          <a class="btn btn-outline-light btn-social" href="https://www.twitter.com"><i class="fab fa-twitter"></i></a>

          <a class="btn btn-outline-light btn-social" href="https://www.facebook.com"><i class="fab fa-facebook-f"></i></a>

          <a class="btn btn-outline-light btn-social" href="https://www.youtube.com"><i class="fab fa-youtube"></i></a>
                            
          <a class="btn btn-outline-light btn-social me-4" href="https://www.instagram.com"><i class="fab fa-instagram"></i></a>
        </div>
      </div>

      <div class="col-lg-3 col-md-6">
        <h4 class="section-title ff-secondary text-start text-primary fw-normal mb-4">Opening</h4>
        <h5 class="text-light fw-normal">Monday - Sunday</h5>
        <p style="margin-bottom:47px;">07AM - 10PM</p>
        <a href="https://app.box.com/s/9e0737sujxse2e3h48agrad45tniqa4e" download>
          <img src="assets/img/download.gif" alt="download" style="width:200px;">
        </a>
      </div>

      <div class="col-lg-3 col-md-6">
        <h4 class="section-title ff-secondary text-start text-primary fw-normal mb-4">Website Links</h4>
        <img src="assets/img/heaven.png" alt="heaven" style="width:100px; display:block; margin-bottom:20px;">
        <a href="http://heaven.pmojt.com/" style="text-decoration:none; color:#ffffff; cursor:pointer;">http://heaven.pmojt.com</a>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="copyright">
      <div class="row">
        <div class="col-12 text-md-start mb-3 mb-md-0">
          <div class="text-center">
            Copyright &copy; 2023 | Designed By - 
            <span class="text-warning"> Name : Thet Hnin Hsu - Student ID Number : 4321 </span>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Footer End -->

<!-- Back to Top -->
<a href="#" class="btn btn-primary rounded-circle back-to-top"><i class="bi bi-arrow-up"></i></a>
