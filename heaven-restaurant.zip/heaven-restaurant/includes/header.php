<nav class="navbar navbar-expand-lg navbar-dark bg-dark px-4 px-lg-5 py-3 py-lg-0">
    <a href="index.php" class="navbar-brand p-0">
        <img src="assets/img/logo.png" alt="Logo">
        <span class="text-primary fs-3 m-0">Heaven Restaurant</span>
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="fa fa-bars"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav ms-auto py-0 pe-4">
            <a href="index.php" class="nav-item nav-link active">Home</a>
            

            <div class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                <div class="dropdown-menu m-0">
                    <a href="#service-id" class="dropdown-item">Service</a>
                    <a href="#about-id" class="dropdown-item">About</a>
                    <a href="#team-id" class="dropdown-item">Our Team</a>
                    <a href="#testimonial-id" class="dropdown-item">Testimonial</a>
                </div>
            </div>

            <a href="contact.php" class="nav-item nav-link">Contact</a>

            <?php if (strlen($_SESSION['uid']==0)) {?>

                <a href="admin/index.php" class="nav-link">Admin</a>

                <a href="login.php" class="nav-item nav-link">Login</a>

                <a href="register.php" class="nav-item nav-link">Register</a>
            <?php }?>

            <?php if (strlen($_SESSION['uid']>0)) {?>
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Menu</a>
                    <div class="dropdown-menu m-0">
                        <a href="menu.php" class="dropdown-item">Menu</a>
                        <a href="search-menu.php" class="dropdown-item">Search Menu</a>
                        <a href="order-history.php" class="dropdown-item">Order History</a>
                    </div>
                </div>

                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Booking</a>
                    <div class="dropdown-menu m-0">
                        <a href="booking.php" class="dropdown-item">Booking</a>
                        <a href="booking-history.php" class="dropdown-item">Booking History</a>
                    </div>
                </div>


                <?php
                    $uid=$_SESSION['uid'];
                    $ret=mysqli_query($con,"select user_fname, user_lname from user where id='$uid'");
                    $row=mysqli_fetch_array($ret);
                    $name=$row['user_fname'].' '.$row['user_lname'];
                ?> 

                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                        <img src="assets/img/user.png" alt="user" style="width:20px; height:20px">
                        <span><?php echo $name; ?></span>
                    </a>

                    <div class="dropdown-menu m-0">
                        <a href="profile.php" class="dropdown-item">Profile</a>
                        
                        <a href="change-password.php" class="dropdown-item">Change Password</a>

                        <a href="logout.php" class="dropdown-item">Logout</a>
                    </div>
                </div>
            <?php }?>
        </div>
    </div>
</nav>