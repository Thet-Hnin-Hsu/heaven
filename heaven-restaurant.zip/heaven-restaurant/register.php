<?php
    session_start();
    error_reporting(0);
    include('includes/dbconnection.php');

    if(isset($_POST['submit']))
    {
        $fname=$_POST['fname'];
        $lname=$_POST['lname'];
        $contno=$_POST['mobile'];
        $email=$_POST['email'];
        $password=md5($_POST['password']);
        $state=$_POST['state'];
        $city=$_POST['city'];
        $address=$_POST['address'];

        $ret=mysqli_query($con, "select user_email from user where user_email='$email' || user_mobile='$contno'");

        $result=mysqli_fetch_array($ret);

        if($result>0) {
            echo "<script>alert('This email or Contact Number already associated with another account!.');</script>";
        } else {
            $query=mysqli_query($con, "insert into user(user_fname, user_lname, user_mobile, user_email, user_password, user_state, user_city, user_address) value('$fname', '$lname','$contno', '$email', '$password', '$state',  '$city', '$address' )");
            
            if ($query) {
                echo "<script>alert('You have successfully registered.');</script>";
            } else {
                echo "<script>alert('Something Went Wrong. Please try again.');</script>";
            }
        }
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Heaven Restaurant - Register</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <link href="assets/img/logo.png" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Nunito:wght@600;700;800&family=Pacifico&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="assets/lib/animate/animate.min.css" rel="stylesheet">
    <link href="assets/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="assets/lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="assets/css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Navbar & Hero Start -->
        <div class="container-xxl position-relative p-0">
            <!-- header start -->
            <?php include_once('includes/header.php');?>
            <!-- header end -->

            <div class="container-xxl py-5 bg-dark hero-header mb-5">
                <div class="container text-center my-5 pt-5 pb-4">
                    <h1 class="display-3 text-white mb-3 animated slideInDown">Register</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center text-uppercase">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item"><a href="#">Pages</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">Register</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Navbar & Hero End -->


        <!-- Register Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="text-center wow fadeInUp mb-5" data-wow-delay="0.1s">
                    <h5 class="section-title ff-secondary text-center text-primary fw-normal">Register</h5>
                </div>

                <div class="row g-4">
                    <div class="col-md-6 wow fadeIn" data-wow-delay="0.1s">
                        <img src="assets/img/register.gif" alt="register" class="w-75">
                    </div>

                    <div class="col-md-6">
                        <div class="wow fadeInUp" data-wow-delay="0.2s">
                            <form method="post" name="register" onsubmit="return checkpass();">
                                <div class="row g-3">
                                    <div class="col-12">
                                        <div class="form-floating">
                                            <input type="text" class="form-control input_field" id="fname" name="fname" placeholder="First Name" required>
                                            <label for="fname">First Name</label>
                                        </div>
                                    </div>

                                    <div class="col-12">
                                        <div class="form-floating">
                                            <input type="text" class="form-control input_field" id="lname" name="lname" placeholder="Last Name" required>
                                            <label for="lname">Last Name</label>
                                        </div>
                                    </div>

                                    <div class="col-12">
                                        <div class="form-floating">
                                            <input type="email" class="form-control input_field" id="email" name="email" placeholder=" Email" required>
                                            <label for="email"> Email</label>
                                        </div>
                                    </div>

                                    <div class="col-12">
                                        <div class="form-floating">
                                            <input type="text" class="form-control input_field" id="mobile" name="mobile" placeholder="Mobile" required pattern="[0-9]+" maxlength="10">
                                            <label for="mobile">Mobile</label>
                                        </div>
                                    </div>
                                    
                                    <div class="col-12">
                                        <div class="form-floating">
                                            <input type="password" class="form-control input_field" id="password" name="password" placeholder="Password" required>
                                            <label for="password">Password</label>
                                        </div>
                                    </div>

                                    <div class="col-12">
                                        <div class="form-floating">
                                            <input type="password" class="form-control input_field" id="repeatpassword" name="repeatpassword" placeholder="Repeat Password" required>
                                            <label for="repeatpassword">Repeat Password</label>
                                        </div>
                                    </div>

                                    <div class="col-12">
                                        <div class="form-floating">
                                            <input type="text" class="form-control input_field" id="state" name="state" placeholder="State" required>
                                            <label for="state">State</label>
                                        </div>
                                    </div>

                                    <div class="col-12">
                                        <div class="form-floating">
                                            <input type="text" class="form-control input_field" id="city" name="city" placeholder="City" required>
                                            <label for="city">City</label>
                                        </div>
                                    </div>

                                    <div class="col-12">
                                        <div class="form-floating">
                                            <textarea class="form-control required input_field" placeholder="Address" id="address" name="address" style="height: 150px"></textarea>
                                            <label for="address">Address</label>
                                        </div>
                                    </div>

                                    <div class="d-flex justify-content-between">

                                        <input type="submit" name="submit" id="submit" value="Register" class="submit_button btn btn-warning px-3" />

                                        <a class="" href="login.php">Already Have Account?</a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Register End -->


        <!-- Footer Start -->
        <?php include_once('includes/footer.php');?>
        <!-- Footer Start -->
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/lib/wow/wow.min.js"></script>
    <script src="assets/lib/easing/easing.min.js"></script>
    <script src="assets/lib/waypoints/waypoints.min.js"></script>
    <script src="assets/lib/counterup/counterup.min.js"></script>
    <script src="assets/lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="assets/lib/tempusdominus/js/moment.min.js"></script>
    <script src="assets/lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="assets/lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- disable body scroll which navbar is in active -->
    <script>
        $(function () {
            $('.navbar-toggler').click(function () {
                $('body').toggleClass('noscroll');
            })
        });
    </script>

    <!-- Repeat Password -->
    <script type="text/javascript">
        function checkpass() {
            if(document.register.password.value!=document.register.repeatpassword.value) {
                alert('Password and Repeat Password field does not match');
                document.register.repeatpassword.focus();
                return false;
            }

            return true;
        } 
    </script>

    <!-- Template Javascript -->
    <script src="assets/js/main.js"></script>
</body>

</html>