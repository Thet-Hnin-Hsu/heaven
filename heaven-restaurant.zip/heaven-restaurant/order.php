<?php 
    session_start();
    error_reporting(0);
    include('includes/dbconnection.php');
    $mid = $_REQUEST['orderid'];
    $currentDate = date('Y-m-d');

    if (strlen($_SESSION['uid']==0)) {
        header('location:logout.php');
    } else {
        if(isset($_POST['submit'])) {
            $uid=$_SESSION['uid'];
            $odate=$_POST['odate'];
            $oadd=$_POST['address'];
            $oph=$_POST['phone'];
            $onum=mt_rand(100000000, 999999999);
    
            $query=mysqli_query($con,"insert into orders(user_id,menu_id,order_phone,order_address,order_number,order_date) value('$uid','$mid','$oph','$oadd','$onum','$odate')");

            if ($query) {
                echo '<script>alert("Order Sent Successful!")</script>';
                echo "<script>window.location.href='menu.php'</script>";  
            } else {
                echo '<script>alert("Something Went Wrong. Please try again")</script>';
            }
        }
    ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Heaven Restaurant - Order</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <link href="assets/img/logo.png" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Nunito:wght@600;700;800&family=Pacifico&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="assets/lib/animate/animate.min.css" rel="stylesheet">
    <link href="assets/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="assets/lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="assets/css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Navbar & Hero Start -->
        <div class="container-xxl position-relative p-0">
            <!-- header start -->
            <?php include_once('includes/header.php');?>
            <!-- header end -->

            <div class="container-xxl py-5 bg-dark hero-header mb-5">
                <div class="container text-center my-5 pt-5 pb-4">
                    <h1 class="display-3 text-white mb-3 animated slideInDown">Order</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center text-uppercase">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item"><a href="#">Pages</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">Order</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Navbar & Hero End -->

        <!-- Order Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="text-center wow fadeInUp mb-5" data-wow-delay="0.1s">
                    <h5 class="section-title ff-secondary text-center text-primary fw-normal">Order</h5>
                </div>

                <div class="row g-4">
                    <div class="col-md-6 offset-md-3">
                        <div class="wow fadeInUp" data-wow-delay="0.2s">
                            <form method="post">
                            <?php
                                $ret=mysqli_query($con,"select * from menu where id='$mid' ");
                                $cnt=1;
                                while ($row=mysqli_fetch_array($ret)) { ?> 
                                    <div class="row g-3">
                                        <div class="col-12">
                                            <div class="form-floating">
                                                <img src="admin/images/<?php echo $row['menu_image']?>" width="120">
                                            </div>
                                        </div>

                                        <div class="col-12">
                                            <div class="form-floating">
                                                <input type="text" class="form-control input_field" id="name" name="name" value="<?php  echo $row['menu_name'];?>" readonly>
                                                <label for="name">Menu Name</label>
                                            </div>
                                        </div>

                                        <div class="col-12">
                                            <div class="form-floating">
                                                <input type="text" class="form-control input_field" id="desc" name="desc" value="<?php  echo $row['menu_description'];?>" readonly>
                                                <label for="desc">Menu Description</label>
                                            </div>
                                        </div>

                                        <div class="col-12">
                                            <div class="form-floating">
                                                <input type="text" class="form-control input_field" id="price" name="price" value="<?php  echo $row['menu_price'];?> $" readonly>
                                                <label for="price">Menu Price</label>
                                            </div>
                                        </div>
                                    </div>
                                <?php $cnt=$cnt+1; } ?>
                                
                                <div class="row g-3 mt-2">
                                    <div class="col-12">
                                        <div class="form-floating">
                                            <input type="text" class="form-control input_field" id="phone" name="phone" value="" required>
                                            <label for="phone">Phone</label>
                                        </div>
                                    </div>

                                    <div class="col-12">
                                        <div class="form-floating">
                                            <input type="text" class="form-control input_field" id="address" name="address" value="" required>
                                            <label for="address">Address</label>
                                        </div>
                                    </div>

                                    <div class="col-12">
                                            <div class="form-floating">
                                                <input type="text" class="form-control input_field" id="odate" name="odate" value="<?php  echo $currentDate;?>" readonly>
                                                <label for="odate">Menu Price</label>
                                            </div>
                                        </div>

                                    <div class="d-flex justify-content-evenly">
                                        <input type="submit" name="submit" id="submit" value="Order Now" class="submit_button btn btn-warning px-3" />
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Order End -->

        <!-- Footer Start -->
        <?php include_once('includes/footer.php');?>
        <!-- Footer End -->
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/lib/wow/wow.min.js"></script>
    <script src="assets/lib/easing/easing.min.js"></script>
    <script src="assets/lib/waypoints/waypoints.min.js"></script>
    <script src="assets/lib/counterup/counterup.min.js"></script>
    <script src="assets/lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="assets/lib/tempusdominus/js/moment.min.js"></script>
    <script src="assets/lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="assets/lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- disable body scroll which navbar is in active -->
    <script>
        $(function () {
            $('.navbar-toggler').click(function () {
                $('body').toggleClass('noscroll');
            })
        });
    </script>

    <!-- Template Javascript -->
    <script src="assets/js/main.js"></script>
</body>

</html>

<?php } ?>
