<div class=" sidebar" role="navigation">
  <div class="navbar-collapse">
    <nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
      <ul class="nav" id="side-menu">
        <li>
          <a href="dashboard.php"><i class="fa fa-home nav_icon"></i>Dashboard</a>
        </li>

        <li>
          <a href="add-menu.php"><i class="fa fa-check-square-o nav_icon"></i>Menu<span class="fa arrow"></span> </a>
          <ul class="nav nav-second-level collapse">
            <li>
              <a href="add-menu.php">Add Menu</a>
            </li>

            <li>
              <a href="manage-menu.php">Manage Menu</a>
            </li>
          </ul>
        </li>
          
        <li>
          <a href="all-booking.php"><i class="fa fa-book nav_icon"></i>Booking<span class="fa arrow"></span></a>
          <ul class="nav nav-second-level collapse">
            <li>
              <a href="all-booking.php">All Booking</a>
            </li>

            <li>
              <a href="new-booking.php">New Booking</a>
            </li>

            <li>
              <a href="accepted-booking.php">Accepted Booking</a>
            </li>

            <li>
              <a href="rejected-booking.php">Rejected Booking</a>
            </li>
          </ul>
        </li>
           
        <li>
          <a href="readenq.php"><i class="fa fa-cogs nav_icon"></i>Enquiry<span class="fa arrow"></span></a>
          <ul class="nav nav-second-level collapse">
            <li>
              <a href="readenq.php">Read Enquiry</a>
            </li>

            <li>
              <a href="unreadenq.php">Unread Enquiry</a>
            </li>
          </ul>
        </li>
        

        <li>
          <a href="customer-list.php"><i class="fa fa-users nav_icon"></i>Lists<span class="fa arrow"></span></a>
          <ul class="nav nav-second-level collapse">
            <li>
              <a href="customer-list.php"> Customer List</a>
            </li>
                   
            <li>
              <a href="admin-list.php"> Admin List</a>
            </li>

            <li>
              <a href="orders.php"> Order List</a>
            </li>
          </ul>
        </li>

        <li>
          <a href="bwdates-reports-ds.php"><i class="fa fa-file-text-o nav_icon"></i>Reports<span class="fa arrow"></span></a>
          <ul class="nav nav-second-level collapse">
            <li>
              <a href="bwdates-reports-ds.php"> B/w dates</a>
            </li>
                   
            <li>
              <a href="sales-reports.php">Sales Reports</a>
            </li>
          </ul>
        </li>

        <li>
          <a href="search-booking.php"><i class="fa fa-search nav_icon"></i>Search<span class="fa arrow"></span></a>
          <ul class="nav nav-second-level collapse">
            <li>
              <a href="search-booking.php"> Search Booking</a>
            </li>
                   
            <li>
              <a href="search-orders.php">Search Orders</a>
            </li>
          </ul>
        </li>
      </ul>

      <div class="clearfix"> </div>
    </nav>
  </div>
</div>