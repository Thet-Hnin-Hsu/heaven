<!--footer-->
<div class="footer">
    <p>
      Copyright &copy; 2023 | Designed By - 
      <span class="footer-span">
      Name : Thet Hnin Hsu - Student ID Number : 4321
      </span>
    </p>
</div>
<!--//footer-->