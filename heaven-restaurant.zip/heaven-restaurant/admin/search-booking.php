<?php
	session_start();
	error_reporting(0);
	include('includes/dbconnection.php');

	if (strlen($_SESSION['aid']==0)) {
		header('location:logout.php');
	} else {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

	<title>Heaven | Search Booking</title>

	<link href="../assets/img/logo.png" rel="icon">

	<!-- Bootstrap CSS -->
	<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />

	<!-- Custom CSS -->
	<link href="css/style.css" rel='stylesheet' type='text/css' />

	<!-- fontawesome css -->
	<link href="css/font-awesome.css" rel="stylesheet"> 

	<!--webfonts css-->
	<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>

	<!--animate css-->
	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">

	<!-- Metis Menu css -->
	<link href="css/custom.css" rel="stylesheet">
</head> 

<body class="cbp-spmenu-push">
	<div class="main-content">

		<!-- header start -->
		 <?php include_once('includes/header.php');?>
		<!-- header end -->

		<!--left-nav start-->
		 <?php include_once('includes/sidebar.php');?>
		<!--left-nav end-->

		<!-- main content start-->
		<div id="page-wrapper" style="background:url('images/bg1.jpg') no-repeat center fixed;">
			<div class="main-page">
				<div class="tables">
					
					<div class="table-responsive bs-example widget-shadow">
						<h3 class="title1">Search Booking</h3>
						<h4>Search Booking / Contact number:</h4>

						<div class="form-body">
							<form method="post" name="search" action="" enctype="multipart/form-data">
							 <div class="form-group"> 
								<label for="searchdata" style="padding-bottom: 20px;">Search by Booking Number / Phone Number / Name</label> 
								<input id="searchdata" type="text" name="searchdata" required class="form-control">
						
								<div>
							  	<button type="submit" name="search" class="btn btn-primary btn-sm" style="background-color: #FEA116; margin-top: 10px; border: none; outline: none;">Search</button> 
							  </div>
							</form> 
						</div>

						<?php
							if(isset($_POST['search'])) { 
								$sdata=$_POST['searchdata'];
							?>
  								<h4 align="center" style="margin-top: 100px;">Result Against "<?php echo $sdata;?>" Keyword </h4> 

								<table class="table table-bordered"> 
									<thead> 
										<tr> 
											<th>#</th> 
											<th>Booking Number</th> 
											<th>Name</th>
											<th>Mobile Number</th> 
											<th>Booking Date</th>
											<th>Booking Time</th>
											<th>Action</th> 
										</tr> 
									</thead> 
									
									<tbody>
										<?php
											$ret=mysqli_query($con,"select user.user_fname,user.user_lname,user.user_email,user.user_mobile,book.id as bid,book.book_number,book.book_date,book.book_time,book.book_message,book.booking_date,book.book_status from book join user on user.id=book.user_id where book.book_number like '%$sdata%' || user.user_mobile like '%$sdata%' || user.user_fname like '%$sdata%'");

											$num=mysqli_num_rows($ret);

											if($num>0) {
												$cnt=1;

												while ($row=mysqli_fetch_array($ret)) {
												?>
						 							<tr> 
														<th scope="row"><?php echo $cnt;?></th> 
														<td><?php  echo $row['book_number'];?></td> 
														<td><?php  echo $row['user_fname'];?> <?php  echo $row['user_lname'];?></td>
														<td><?php  echo $row['user_mobile'];?></td>
														<td><?php  echo $row['book_date'];?></td> 
														<td><?php  echo $row['book_time'];?></td> 
														<td>
															<a href="view-booking.php?viewid=<?php echo $row['bid'];?>" class="btn btn-primary link-view">View</a>
														</td> 
													</tr>   
													
												<?php 
													$cnt=$cnt+1;
												} } else { ?>
													<tr>
														<td colspan="8"> No record found against this search</td>
													</tr>
														
											<?php } }?>
									</tbody> 
								</table> 
					</div>
				</div>
			</div>
		</div>

		<!--footer start-->
		<div class="all-footer">
			<?php include_once('includes/footer.php');?>
		</div>
        <!--footer end-->
	</div>

	<script type="application/x-javascript"> 
		addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } 
	</script>

	<!-- js-->
	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/modernizr.custom.js"></script>

	<!--animate js-->
	<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>

	<!-- Metis Menu js -->
	<script src="js/metisMenu.min.js"></script>
	<script src="js/custom.js"></script>

	<!-- Classie js -->
	<script src="js/classie.js"></script>
	<script>
		var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
			showLeftPush = document.getElementById( 'showLeftPush' ),
			body = document.body;
				
		showLeftPush.onclick = function() {
			classie.toggle( this, 'active' );
			classie.toggle( body, 'cbp-spmenu-push-toright' );
			classie.toggle( menuLeft, 'cbp-spmenu-open' );
			disableOther( 'showLeftPush' );
		};
			
		function disableOther( button ) {
			if( button !== 'showLeftPush' ) {
				classie.toggle( showLeftPush, 'disabled' );
			}
		}
	</script>

	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>

	<!-- Bootstrap js -->
	<script src="js/bootstrap.js"> </script>
</body>
</html>
<?php }  ?>