<?php
	session_start();
	error_reporting(0);
	include('includes/dbconnection.php');

	if (strlen($_SESSION['aid']==0)) {
		header('location:logout.php');
	} else {
		$ordnum = $_GET['ordersid'];
	?>

<!DOCTYPE html>
<html lang="en">
<head>
  	<meta charset="utf-8">
  	<meta content="width=device-width, initial-scale=1.0" name="viewport">
  	<meta content="" name="keywords">
  	<meta content="" name="description">

	<title>Heaven | View Oders</title>

	<link href="../assets/img/logo.png" rel="icon">

	<!-- Bootstrap CSS -->
	<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />

	<!-- Custom CSS -->
	<link href="css/style.css" rel='stylesheet' type='text/css' />

	<!-- fontawesome css -->
	<link href="css/font-awesome.css" rel="stylesheet"> 

	<!--webfonts css-->
	<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>

	<!--animate css-->
	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">

	<!--Metis Menu css -->
	<link href="css/custom.css" rel="stylesheet">
</head> 

<body class="cbp-spmenu-push">
	<div class="main-content">

		<!-- header start -->
		<?php include_once('includes/header.php');?>
		<!-- header end -->

		<!--left-nav start-->
		<?php include_once('includes/sidebar.php');?>
		<!--left-nav end-->

		<!-- main content start-->
		<div id="page-wrapper" style="background:url('images/bg1.jpg') no-repeat center fixed;">
			<div class="main-page">
				<div class="tables" id="exampl">
					
					<div class="table-responsive bs-example widget-shadow">
						<h3 class="title1">Orders Details</h3>

						<?php
							$ord=mysqli_query($con,"select * from orders where orders.order_number='$ordnum'");
							$row=mysqli_fetch_array($ord);
							?>				
								<table class="table table-bordered" width="100%" border="1"> 
									<tr>
										<th colspan="6">Order Details</th>	
									</tr>

									<tr> 
										<th>Phone</th> 
										<td><?php echo $row['order_phone']?></td> 

										<th>Address </th> 
										<td><?php echo $row['order_address']?></td>
									</tr> 

									<tr> 
										<th>Number</th> 
										<td><?php echo $row['order_number']?></td>

										<th>Date</th> 
										<td><?php echo $row['order_date']?></td>
									</tr> 
								</table> 
						
						<?php
							$uid=$row['user_id'];
							$cus=mysqli_query($con,"select * from user where user.id='$uid'");
							$row1=mysqli_fetch_array($cus);
							?>				
								<table class="table table-bordered" width="100%" border="1"> 
									<tr>
										<th colspan="6">Customer Details</th>	
									</tr>

									<tr> 
										<th>Name</th> 
										<td><?php  echo $row1['user_fname'];?> <?php  echo $row1['user_lname'];?></td> 

										<th>Email </th> 
										<td><?php echo $row1['user_email']?></td>

										<th>Contact no.</th> 
										<td><?php echo $row1['user_mobile']?></td>
									</tr> 

									<tr> 
										<th>State</th> 
										<td><?php echo $row1['user_state']?></td>

										<th>City</th> 
										<td><?php echo $row1['user_city']?></td>

										<th>Address</th> 
										<td><?php echo $row1['user_address']?></td>
									</tr> 
								</table> 
								
						<?php
							$mid=$row['menu_id'];
							$meu=mysqli_query($con,"select * from menu where menu.id='$mid'");
							$row2=mysqli_fetch_array($meu);
							?>			
								<table class="table table-bordered" width="100%" border="1"> 
									<tr>
										<th colspan="3">Menu Details</th>	
									</tr>
										<th>Image</th>
										<th>Name</th>
										<th>Description</th>
										<th>Price</th>
									</tr>

									<tr>
										<td><img src="images/<?php echo $row2['menu_image']?>" width="40" height="40px"></td>	
										<td><?php echo $row2['menu_name']?></td>	
										<td><?php echo $row2['menu_description']?></td>	
										<td><?php echo $subtotal=$row2['menu_price']?> $</td>
									</tr>
								</table>

								<p style="margin-top:1%"  align="center">
									<i class="fa fa-print fa-2x" style="cursor: pointer; color: #FEA116;"  OnClick="CallPrint(this.value)" ></i>
								</p>
					</div>
				</div>
			</div>
		</div>

		<!--footer start-->
		<div class="all-footer">
			<?php include_once('includes/footer.php');?>
		</div>
        <!--footer end-->
	</div>

	<script type="application/x-javascript"> 
		addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } 
	</script>

	<!-- js-->
	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/modernizr.custom.js"></script>

	<!--animate js-->
	<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>

	<!-- Metis Menu js -->
	<script src="js/metisMenu.min.js"></script>
	<script src="js/custom.js"></script>

	<!-- Classie js -->
	<script src="js/classie.js"></script>
	<script>
		var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
			showLeftPush = document.getElementById( 'showLeftPush' ),
			body = document.body;
				
		showLeftPush.onclick = function() {
			classie.toggle( this, 'active' );
			classie.toggle( body, 'cbp-spmenu-push-toright' );
			classie.toggle( menuLeft, 'cbp-spmenu-open' );
			disableOther( 'showLeftPush' );
		};
			
		function disableOther( button ) {
			if( button !== 'showLeftPush' ) {
				classie.toggle( showLeftPush, 'disabled' );
			}
		}
	</script>

	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>

	<!-- Bootstrap js -->
	<script src="js/bootstrap.js"> </script>

	<script>
		function CallPrint(strid) {
			var prtContent = document.getElementById("exampl");
			var WinPrint = window.open('', '', 'left=0,top=0,width=800,height=900,toolbar=0,scrollbars=0,status=0');
			WinPrint.document.write(prtContent.innerHTML);
			WinPrint.document.close();
			WinPrint.focus();
			WinPrint.print();
			WinPrint.close();
		}
	</script>
</body>
</html>
<?php }  ?>