<?php
  session_start();
  error_reporting(0);
  include('includes/dbconnection.php');

  if (strlen($_SESSION['aid']==0)) {
    header('location:logout.php');
  } else {
    if(isset($_POST['submit'])) {
      $cid=$_GET['viewid'];
      $remark=$_POST['remark'];
      $status=$_POST['status'];

      $query=mysqli_query($con, "update book set book_remark='$remark',book_status='$status' where id='$cid'");

      if ($query) {
        echo '<script>alert("All remark has been updated.")</script>';
        echo "<script type='text/javascript'> document.location ='all-booking.php'; </script>";
      } else {
        echo '<script>alert("Something Went Wrong. Please try again")</script>';
      }
    }
  ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <title>Heaven | View Booking</title>

	<link href="../assets/img/logo.png" rel="icon">

  <!-- Bootstrap CSS -->
  <link href="css/bootstrap.css" rel='stylesheet' type='text/css' />

  <!-- Custom CSS -->
  <link href="css/style.css" rel='stylesheet' type='text/css' />

  <!-- fontawesome css -->
  <link href="css/font-awesome.css" rel="stylesheet"> 

   <!--webfonts css-->
   <link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>

  <!--animate css-->
  <link href="css/animate.css" rel="stylesheet" type="text/css" media="all">

  <!-- Metis Menu css -->
  <link href="css/custom.css" rel="stylesheet">
</head> 

<body class="cbp-spmenu-push">
	<div class="main-content">

		<!-- header start -->
		<?php include_once('includes/header.php');?>
		<!-- header end -->

		<!--left-nav start-->
		<?php include_once('includes/sidebar.php');?>
		<!--left-nav end-->

		<!-- main content start-->
		<div id="page-wrapper" style="background:url('images/bg1.jpg') no-repeat center fixed;">
			<div class="main-page">
				<div class="tables">
          
          <div class="table-responsive bs-example widget-shadow">
            <h3 class="title1">View Booking</h3>
						<h4>View Booking:</h4>

              <?php
                $cid=$_GET['viewid'];

                $ret=mysqli_query($con,"select user.user_fname,user.user_lname,user.user_email,user.user_mobile,book.id as bid,book.book_number,book.book_date,book.book_time,book.book_message,book.booking_date,book.book_remark,book.book_status,book.book_remarkdate from book join user on user.id=book.user_id where book.id='$cid'");

                $cnt=1;

                while ($row=mysqli_fetch_array($ret)) {
                ?>
                  <table class="table table-bordered">
                    <tr>
                      <th>Booking Number</th>
                      <td><?php  echo $row['book_number'];?></td>
                    </tr>
                    
                    <tr>
                      <th>Name</th>
                      <td><?php  echo $row['user_fname'];?> <?php  echo $row['user_lname'];?></td>
                    </tr>

                    <tr>
                      <th>Email</th>
                      <td><?php  echo $row['user_email'];?></td>
                    </tr>

                    <tr>
                      <th>Mobile Number</th>
                      <td><?php  echo $row['user_mobile'];?></td>
                    </tr>

                    <tr>
                      <th>Booking Date</th>
                      <td><?php  echo $row['book_date'];?></td>
                    </tr>
 
                    <tr>
                      <th>Booking Time</th>
                      <td><?php  echo $row['book_time'];?></td>
                    </tr>
  
                    <tr>
                      <th>Apply Date</th>
                      <td><?php  echo $row['booking_date'];?></td>
                    </tr>
  
                    <tr>
                      <th>Status</th>
                      <td> 
                        <?php  
                          if($row['book_status']=="") {
                            echo "Not Updated Yet";
                          }

                          if($row['book_status']=="Selected") {
                            echo "Selected";
                          }

                          if($row['book_status']=="Rejected") {
                            echo "Rejected";
                          }
                        ;?>
                      </td>
                    </tr>
						      </table>

						      <table class="table table-bordered">
							      <?php 
                      if($row['book_status']=="") { 
                      ?>
                        <form name="submit" method="post" enctype="multipart/form-data"> 
                          <tr>
                            <th>Remark :</th>
                            <td>
                              <textarea name="remark" placeholder="" rows="12" cols="14" class="form-control wd-450" required></textarea>
                            </td>
                          </tr>

                          <tr>
                            <th>Status :</th>
                            <td>
                              <select name="status" class="form-control wd-450" required >
                                <option value="Selected" selected>Selected</option>
                                <option value="Rejected">Rejected</option>
                              </select>
                            </td>
                          </tr>

                          <tr align="center">
                            <td colspan="2"><button type="submit" name="submit" class="btn btn-primary link-view">Submit</button></td>
                          </tr>
                        </form>
                      <?php } else { ?>
						      </table>

						      <table class="table table-bordered">
							      <tr>
                      <th>Remark</th>
                      <td><?php echo $row['book_remark']; ?></td>
                    </tr>
                    <tr>
                      <th>Status</th>
                      <td><?php echo $row['book_status']; ?></td>
                    </tr>

                    <tr>
                      <th>Remark date</th>
                      <td><?php echo $row['book_remarkdate']; ?>  </td>
                    </tr>
						      </table>
						    <?php } ?>
						  <?php } ?>
					</div>
				</div>
			</div>
		</div>

		<!--footer start-->
		<div class="all-footer">
			<?php include_once('includes/footer.php');?>
		</div>
    <!--footer end-->
	</div>

  <script type="application/x-javascript"> 
    addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } 
  </script>

  <!-- js-->
  <script src="js/jquery-1.11.1.min.js"></script>
  <script src="js/modernizr.custom.js"></script>

  <!--animate js-->
  <script src="js/wow.min.js"></script>
	<script>
		new WOW().init();
	</script>

  <!-- Metis Menu js -->
  <script src="js/metisMenu.min.js"></script>
  <script src="js/custom.js"></script>

	<!-- Classie js -->
	<script src="js/classie.js"></script>
	<script>
		var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
			showLeftPush = document.getElementById( 'showLeftPush' ),
			body = document.body;
				
		showLeftPush.onclick = function() {
			classie.toggle( this, 'active' );
			classie.toggle( body, 'cbp-spmenu-push-toright' );
			classie.toggle( menuLeft, 'cbp-spmenu-open' );
			disableOther( 'showLeftPush' );
		};
			
		function disableOther( button ) {
			if( button !== 'showLeftPush' ) {
				classie.toggle( showLeftPush, 'disabled' );
			}
		}
	</script>

	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>

	<!-- Bootstrap js -->
	<script src="js/bootstrap.js"> </script>
</body>
</html>
<?php }  ?>