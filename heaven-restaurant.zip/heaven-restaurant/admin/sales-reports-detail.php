<?php
	session_start();
	error_reporting(0);
	include('includes/dbconnection.php');

	if (strlen($_SESSION['aid']==0)) {
		header('location:logout.php');
	} else {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

	<title>Heaven | Sales Reports</title>

	<link href="../assets/img/logo.png" rel="icon">

	<!-- Bootstrap CSS -->
	<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />

	<!-- Custom CSS -->
	<link href="css/style.css" rel='stylesheet' type='text/css' />

	<!-- fontawesome css -->
	<link href="css/font-awesome.css" rel="stylesheet"> 

	<!--webfonts css-->
	<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>

	<!--animate css-->
	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">

	<!-- Metis Menu css -->
	<link href="css/custom.css" rel="stylesheet">
</head> 

<body class="cbp-spmenu-push">
	<div class="main-content">

		<!-- header start -->
		 <?php include_once('includes/header.php');?>
		<!-- header end -->

		<!--left-nav start-->
		 <?php include_once('includes/sidebar.php');?>
		<!--left-nav end-->

		<!-- main content start-->
		<div id="page-wrapper" style="background:url('images/bg1.jpg') no-repeat center fixed;">
			<div class="main-page">
				<div class="tables">
					
					<div class="table-responsive bs-example widget-shadow">	
						<h3 class="title1">Sales Reports</h3>
 				  		<?php
							$fdate=$_POST['fromdate'];
							$tdate=$_POST['todate'];
							$rtype=$_POST['requesttype'];
						?>

						<?php 
							if($rtype=='mtwise') {
								$month1=strtotime($fdate);
								$month2=strtotime($tdate);
								$m1=date("F",$month1);
								$m2=date("F",$month2);
								$y1=date("Y",$month1);
								$y2=date("Y",$month2);
							?>
								<h4 class="header-title m-t-0 m-b-30">Sales Report Month Wise</h4>
								<h4 align="center" style="color:#FEA116">Sales Report  from <?php echo $m1."-".$y1;?> to <?php echo $m2."-".$y2;?></h4>

								<hr />

								<table class="table table-bordered" style="margin-bottom: 100px;">  
									<thead>
										<tr>
											<th>S.NO</th>
											<th>Month / Year </th>
											<th>Sales</th>
										</tr>
									</thead>

									<?php
										$ret=mysqli_query($con,"select month(order_date) as lmonth,year(order_date) as lyear,sum(menu_price) as totalprice from orders join menu on menu.id=orders.menu_id where date(orders.order_date) between '$fdate' and '$tdate' group by lmonth,lyear");
										$cnt=1;

										while ($row=mysqli_fetch_array($ret)) {
										?>
              
                							<tr>
                    							<td><?php echo $cnt;?></td>
                  								<td><?php  echo $row['lmonth']."/".$row['lyear'];?></td>
              									<td><?php  echo $total=$row['totalprice'];?> $</td>
                    						</tr>

                							<?php
												$ftotal+=$total;
												$cnt++;
										}?>

										<tr>
                  							<td colspan="2" align="center">Total </td>
              								<td><?php  echo $ftotal;?> $</td>
                						</tr>
								</table> 
                			<?php } else {
								$year1=strtotime($fdate);
								$year2=strtotime($tdate);
								$y1=date("Y",$year1);
								$y2=date("Y",$year2);
 							?>
								<h4 class="header-title m-t-0 m-b-30">Sales Report Year Wise</h4>
								<h4 align="center" style="color:#FEA116">Sales Report  from <?php echo $y1;?> to <?php echo $y2;?></h4>

								<hr />

								<table class="table table-bordered">  
									<thead>
										<tr>
											<th>S.NO</th>
											<th>Year </th>
											<th>Sales</th>
										</tr>
									</thead>

									<?php
										$ret=mysqli_query($con,"select year(order_date) as lyear,sum(menu_price) as totalprice from  orders join menu on menu.id= orders.menu_id where date(orders.order_date) between '$fdate' and '$tdate' group by lyear");
										$cnt=1;

										while ($row=mysqli_fetch_array($ret)) {
										?>
											<tr>
												<td><?php echo $cnt;?></td>
												<td><?php  echo $row['lyear'];?></td>
												<td><?php  echo $total=$row['totalprice'];?></td>
											</tr>

                							<?php
												$ftotal+=$total;
												$cnt++;
										}?>

										<tr>
											<td colspan="2" align="center">Total </td>
											<td><?php  echo $ftotal;?></td>
							
										</tr>
								</table>
                			<?php } ?>	
					</div>
				</div>
			</div>
		</div>

		<!--footer start-->
		<div class="all-footer">
			<?php include_once('includes/footer.php');?>
		</div>
        <!--footer end-->
	</div>

	<script type="application/x-javascript"> 
		addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } 
	</script>

	<!-- js-->
	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/modernizr.custom.js"></script>

	<!--animate js-->
	<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>

	<!-- Metis Menu js -->
	<script src="js/metisMenu.min.js"></script>
	<script src="js/custom.js"></script>

	<!-- Classie js -->
	<script src="js/classie.js"></script>
	<script>
		var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
			showLeftPush = document.getElementById( 'showLeftPush' ),
			body = document.body;
				
		showLeftPush.onclick = function() {
			classie.toggle( this, 'active' );
			classie.toggle( body, 'cbp-spmenu-push-toright' );
			classie.toggle( menuLeft, 'cbp-spmenu-open' );
			disableOther( 'showLeftPush' );
		};
			
		function disableOther( button ) {
			if( button !== 'showLeftPush' ) {
				classie.toggle( showLeftPush, 'disabled' );
			}
		}
	</script>

	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>

	<!-- Bootstrap js -->
	<script src="js/bootstrap.js"> </script>
</body>
</html>
<?php }  ?>