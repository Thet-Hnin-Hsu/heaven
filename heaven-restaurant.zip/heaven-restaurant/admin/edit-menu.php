<?php
	session_start();
	error_reporting(0);
	include('includes/dbconnection.php');

	if (strlen($_SESSION['aid']==0)) {
		header('location:logout.php');
	} else {
		if(isset($_POST['submit'])) {
			$menu_name=$_POST['menuname'];
			$menu_desc=$_POST['menudesc'];
			$menu_price=$_POST['price'];
			$eid=$_GET['editid'];
		
			$query=mysqli_query($con, "update menu set menu_name='$menu_name',menu_description='$menu_desc',menu_price='$menu_price' where id='$eid' ");

			if ($query) {
				echo "<script>alert('Menu has been Updated.');</script>";
			} else {
				echo "<script>alert('Something Went Wrong. Please try again.');</script>";
			}
		}
  		?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

	<title>Heaven | Update Menu</title>

	<link href="../assets/img/logo.png" rel="icon">


	<!-- Bootstrap CSS -->
	<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />

	<!-- Custom CSS -->
	<link href="css/style.css" rel='stylesheet' type='text/css' />

	<!-- font-awesome icons -->
	<link href="css/font-awesome.css" rel="stylesheet"> 

	<!--webfonts css-->
	<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>

	<!--animate css-->
	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">

	<!-- Metis Menu vss -->
	<link href="css/custom.css" rel="stylesheet">
</head> 

<body class="cbp-spmenu-push">
	<div class="main-content">
		<!-- header start -->
		 <?php include_once('includes/header.php');?>
		<!-- header end -->

		<!--left-nav start-->
		 <?php include_once('includes/sidebar.php');?>
		<!--left-nav end-->

		<!-- main content start-->
		<div id="page-wrapper" style="background:url('images/bg1.jpg') no-repeat center fixed;">
			<div class="main-page">
				<div class="forms">
					
					<div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
						<div class="form-title">
							<h3 class="title1">Update Menu</h3>
							<h4 style="margin-top: 25px;">Update Menu:</h4>
						</div>

						<div class="form-body">
							<form method="post" enctype="multipart/form-data">		
  								<?php
 									$cid=$_GET['editid'];
									$ret=mysqli_query($con,"select * from menu where id='$cid'");
									$cnt=1;

									while ($row=mysqli_fetch_array($ret)) {
									?> 
							 			<div class="form-group"> 
											<label for="menuname">Menu Name</label> 
											<input type="text" class="form-control" id="menuname" name="menuname" placeholder="Menu Name" value="<?php  echo $row['menu_name'];?>" required> 
										</div>

							 			<div class="form-group"> 
											<label for="menudesc">Menu Description</label> 
											<textarea type="text" class="form-control" id="menudesc" name="menudesc" placeholder="Menu Description" value="" required><?php  echo $row['menu_description'];?></textarea> 
										</div>

							 			<div class="form-group"> 
											<label for="price">Price</label> 
											<input type="number" id="price" name="price" class="form-control" placeholder="Price" value="<?php  echo $row['menu_price'];?>" required> 
										</div>

							 			<div class="form-group"> 
											<label for="image" style="margin-right: 30px;">Image</label> 
											<img src="images/<?php echo $row['menu_image']?>" width="100px;">
											<a href="update-image.php?lid=<?php echo $row['id'];?>" style="margin-left: 30px; color:#FEA116;">Update Image</a> 
										</div>
							 		<?php } ?>

							  	<button type="submit" name="submit" class="btn btn-default" style="background-color: #FEA116; border: none; outline: none;">Update</button> 
							</form> 
						</div>
						
					</div>
				</div>
			</div>
		</div>

		<!-- footer start -->
		<div class="all-footer">
			<?php include_once('includes/footer.php');?>
		</div>
		<!-- footer end -->
	</div>

	<script type="application/x-javascript"> 
		addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } 
	</script>

	<!-- js-->
	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/modernizr.custom.js"></script>

	<!--animate js-->
	<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>

	<!-- Metis Menu js -->
	<script src="js/metisMenu.min.js"></script>
	<script src="js/custom.js"></script>

	<!-- Classie js -->
	<script src="js/classie.js"></script>
	<script>
		var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
			showLeftPush = document.getElementById( 'showLeftPush' ),
			body = document.body;
				
		showLeftPush.onclick = function() {
			classie.toggle( this, 'active' );
			classie.toggle( body, 'cbp-spmenu-push-toright' );
			classie.toggle( menuLeft, 'cbp-spmenu-open' );
			disableOther( 'showLeftPush' );
		};
			
		function disableOther( button ) {
			if( button !== 'showLeftPush' ) {
				classie.toggle( showLeftPush, 'disabled' );
			}
		}
	</script>

	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>

	<!-- Bootstrap js -->
   <script src="js/bootstrap.js"> </script>
</body>
</html>
<?php } ?>