<?php
	session_start();
	error_reporting(0);
	include('includes/dbconnection.php');

	if(isset($_POST['submit']))
	{
		$mobile=$_POST['mobile'];
		$email=$_POST['email'];
		$password=md5($_POST['newpassword']);
		
		$query=mysqli_query($con,"select id from admin where  admin_email='$email' and admin_mobile='$mobile' ");

		$ret=mysqli_fetch_array($query);
		if($ret>0) {
			$_SESSION['mobile']=$mobile;
			$_SESSION['email']=$email;

			$query1=mysqli_query($con,"update admin set admin_password='$password'  where  admin_email='$email' && admin_mobile='$mobile' ");

			if($query1) {
				echo "<script>alert('Password successfully changed');</script>";
				session_destroy();
			}
		} else {
			$msg="Invalid Details. Please try again.";
		}
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

	<title>Heaven | Forgot Password </title>

	<link href="../assets/img/logo.png" rel="icon">

	<!-- Bootstrap CSS -->
	<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />

	<!-- Custom CSS -->
	<link href="css/style.css" rel='stylesheet' type='text/css' />

	<!-- font-awesome icons -->
	<link href="css/font-awesome.css" rel="stylesheet"> 

	<!--webfonts css-->
	<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>

	<!--animate css-->
	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">

	<!-- Metis Menu css -->
	<link href="css/custom.css" rel="stylesheet">
</head> 

<body class="cbp-spmenu-push"  style="background:url('images/bg1.jpg') no-repeat center fixed;">
	<div class="main-content">
		
		<!-- main content start-->
		<div class="login-main" style="background:url('images/bg1.jpg') no-repeat center fixed;">			
			<div class="main-page login-page ">
				<div class="widget-shadow">
					<div class="login-top">
						<h3 class="title1">Forgot Password</h3>
						<h4>Welcome To AdminPanel ! </h4>
					</div>

					<div class="login-body">
						<form role="form" method="post" action="" name="changepassword" onsubmit="return checkpass();" enctype="multipart/form-data">
							<p style="font-size:16px; color:red" align="center"> 
								<?php 
									if($msg) {
										echo $msg;
									}  
								?> 
							</p>

							<input type="text" name="email" class="lock" placeholder="Email" required>
							
							<input type="text" name="mobile" class="lock" placeholder="Mobile Number" required maxlength="10" pattern="[0-9]+">

							<input type="password" name="newpassword" class="lock" placeholder="New Password" required>
							
							<input type="password" name="confirmpassword" class="lock" placeholder="Confirm Password" required>
							
							<input type="submit" name="submit" value="RESET">

							<div class="forgot-grid">
								<div class="forgot">
									<a href="index.php">Already have Account?</a>
								</div>

								<div class="clearfix"> </div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		
		<!--footer start-->
		<div class="login-footer"></div>
			<?php include_once('includes/footer.php');?>
		</div>
        <!--footer end-->
	</div>

	<script type="application/x-javascript"> 
		addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } 
	</script>

	<!-- js-->
	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/modernizr.custom.js"></script>

	<!--animate js-->
	<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>

	<!-- Metis Menu -->
	<script src="js/metisMenu.min.js"></script>
	<script src="js/custom.js"></script>

	<!-- change password -->
	<script type="text/javascript">
		function checkpass() {
			if(document.changepassword.newpassword.value!=document.changepassword.confirmpassword.value) {
			alert('New Password and Confirm Password field does not match');
			document.changepassword.confirmpassword.focus();
			return false;
			}
			
			return true;
		} 
	</script>

	<!-- Classie -->
		<script src="js/classie.js"></script>
		<script>
			var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
				showLeftPush = document.getElementById( 'showLeftPush' ),
				body = document.body;
				
			showLeftPush.onclick = function() {
				classie.toggle( this, 'active' );
				classie.toggle( body, 'cbp-spmenu-push-toright' );
				classie.toggle( menuLeft, 'cbp-spmenu-open' );
				disableOther( 'showLeftPush' );
			};
			
			function disableOther( button ) {
				if( button !== 'showLeftPush' ) {
					classie.toggle( showLeftPush, 'disabled' );
				}
			}
		</script>
	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!--//scrolling js-->
	<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.js"> </script>
</body>
</html>