<?php
	session_start();
	error_reporting(0);
	include('includes/dbconnection.php');

	if (strlen($_SESSION['aid']==0)) {
		header('location:logout.php');
	} else {
		if(isset($_POST['submit'])) {
			$image=$_FILES["image"]["name"];
			$extension = substr($image,strlen($image)-4,strlen($image));
			$allowed_extensions = array(".jpg","jpeg",".png",".gif",".webp",".svg");

			if(!in_array($extension,$allowed_extensions)) {
				echo "<script>alert('Invalid format. Only jpg / jpeg/ png/ gif/ webp/ svg/ format allowed');</script>";
			} else {
				$newimage=md5($image).time().$extension;
				move_uploaded_file($_FILES["image"]["tmp_name"],"images/".$newimage);
	
				$eid=$_GET['lid'];
		
				$query=mysqli_query($con, "update menu set menu_image='$newimage' where id='$eid' ");

				if ($query) {
					echo "<script>alert('menu Image has been Updated.');</script>";
				} else {
					echo "<script>alert('Something Went Wrong. Please try again.');</script>";
				}
			}
		}
	?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

	<title>Heaven | Update Menu</title>

	<link href="../assets/img/logo.png" rel="icon">

	<script type="application/x-javascript"> 
		addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } 
	</script>

	<!-- Bootstrap CSS -->
	<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />

	<!-- Custom CSS -->
	<link href="css/style.css" rel='stylesheet' type='text/css' />

	<!-- fontawesome css -->
	<link href="css/font-awesome.css" rel="stylesheet"> 

	<!--webfonts css-->
	<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>

	<!--animate css-->
	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">

	<!-- Metis Menu css -->
	<link href="css/custom.css" rel="stylesheet">	
</head> 

<body class="cbp-spmenu-push">
	<div class="main-content">

		<!-- header start -->
		 <?php include_once('includes/header.php');?>
		<!-- header end -->

		<!--left-nav start-->
		 <?php include_once('includes/sidebar.php');?>
		<!--left-nav end-->

		<!-- main content start-->
		<div id="page-wrapper" style="background:url('images/bg1.jpg') no-repeat center fixed;">
			<div class="main-page">
				<div class="forms">
					<div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
						<div class="form-title">
							<h3 class="title1">Update Menu</h3>
							<h4 style="margin-top: 25px;">Update Menu:</h4>
						</div>

						<div class="form-body">
							<form method="post" enctype="multipart/form-data">	
								<?php
									$cid=$_GET['lid'];
									$ret=mysqli_query($con,"select * from menu where id='$cid'");
									$cnt=1;

									while ($row=mysqli_fetch_array($ret)) {
									?> 
							 			<div class="form-group"> 
											<label for="menuname">Menu Name</label> 
											<input type="text" class="form-control" id="menuname" name="menuname" placeholder="Menu Name" value="<?php  echo $row['menu_name'];?>" readonly> 
										</div>
							 
							 			<div class="form-group" style="margin: 25px 0px;"> 
											<label for="image" style="margin-right: 20px;">Old Image</label>  
											<img src="images/<?php echo $row['menu_image']?>" width="120">
               							</div>

               							<div class="form-group"> 
											<label for="image">New Images</label> 
											<input type="file" class="form-control" id="image" name="image" value="" required> 
										</div>
							 		<?php } ?>

							  	<button type="submit" name="submit" class="btn btn-default" style="background-color: #FEA116; outline: none; border: none;">Update</button> 
							</form> 
						</div>	
					</div>
				</div>
			</div>
		</div>

		<!-- footer start -->
		<div class="all-footer">
			<?php include_once('includes/footer.php');?>
		</div>
		<!-- footer end -->
	</div>

	<script type="application/x-javascript"> 
		addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } 
	</script>

	<!-- js-->
	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/modernizr.custom.js"></script>

	<!--animate js-->
	<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>

	<!-- Metis Menu js -->
	<script src="js/metisMenu.min.js"></script>
	<script src="js/custom.js"></script>


	<!-- Classie js -->
	<script src="js/classie.js"></script>
	<script>
		var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
			showLeftPush = document.getElementById( 'showLeftPush' ),
			body = document.body;
				
		showLeftPush.onclick = function() {
			classie.toggle( this, 'active' );
			classie.toggle( body, 'cbp-spmenu-push-toright' );
			classie.toggle( menuLeft, 'cbp-spmenu-open' );
			disableOther( 'showLeftPush' );
		};
			
		function disableOther( button ) {
			if( button !== 'showLeftPush' ) {
				classie.toggle( showLeftPush, 'disabled' );
			}
		}
	</script>

	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>

	<!-- Bootstrap js -->
   <script src="js/bootstrap.js"> </script>
</body>
</html>
<?php } ?>