<?php
	session_start();
	error_reporting(0);
	include('includes/dbconnection.php');

	if (strlen($_SESSION['aid']==0)) {
		header('location:logout.php');
	} else {
		if(isset($_POST['submit'])) {
			$adminid=$_SESSION['aid'];
			$cpassword=md5($_POST['currentpassword']);
			$newpassword=md5($_POST['newpassword']);
			$query=mysqli_query($con,"select id from admin where id='$adminid' and admin_password='$cpassword'");
			$row=mysqli_fetch_array($query);

			if($row>0) {
				$ret=mysqli_query($con,"update admin set admin_password='$newpassword' where id='$adminid'");
				$msg= "Your password successully changed"; 
			} else {
				$msg="Your current password is wrong";
			}
			}
		?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

	<title>Heaven | Change Password</title>

	<link href="../assets/img/logo.png" rel="icon">

	<!-- Bootstrap CSS -->
	<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />

	<!-- Custom CSS -->
	<link href="css/style.css" rel='stylesheet' type='text/css' />

	<!-- fontawesome css -->
	<link href="css/font-awesome.css" rel="stylesheet"> 

	<!--webfonts css-->
	<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>

	<!--animate css-->
	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">

	<!-- Metis Menu css -->
	<link href="css/custom.css" rel="stylesheet">
</head> 

<body class="cbp-spmenu-push">
	<div class="main-content">

		<!-- header start -->
		 <?php include_once('includes/header.php');?>
		<!-- header end -->

		<!--left-nav start-->
		 <?php include_once('includes/sidebar.php');?>
		<!--left-nav end-->

		<!-- main content start-->
		<div id="page-wrapper" style="background:url('images/bg1.jpg') no-repeat center fixed;">
			<div class="main-page">
				<div class="forms">
					
					<div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
						<div class="form-title">
							<h3 class="title1">Change Password</h3>
							<h4 style="margin-top: 25px;">Reset Your Password :</h4>
						</div>

						<div class="form-body">
							<form method="post" name="changepassword" onsubmit="return checkpass();" action="" enctype="multipart/form-data">
								<p style="font-size:16px; color:red" align="center"> 
									<?php if($msg) {
    									echo $msg;
  									}  ?> 
								</p>

  								<?php
									$adminid=$_SESSION['aid'];
									$ret=mysqli_query($con,"select * from admin where id='$adminid'");
									$cnt=1;

									while ($row=mysqli_fetch_array($ret)) { ?>
							 			<div class="form-group"> 
											<label for="currentpassword">Current Password</label> 
											<input type="password" name="currentpassword" id="currentpassword" class="form-control" required value=""> 
										</div> 
										
										<div class="form-group"> 
											<label for="newpassword">New Password</label> 
											<input type="password" name="newpassword" id="newpassword" class="form-control" value="" required> 
										</div>

							 			<div class="form-group"> 
											<label for="confirmpassword">Confirm Password</label> 
											<input type="password" name="confirmpassword" id="confirmpassword" class="form-control" value="" required> 
										</div>
							  
							  			<button type="submit" name="submit" class="btn btn-default" style="background-color: #FEA116; outline: none; border: none;">Change</button> 
									<?php } ?>
							</form> 
						</div>
					</div>
				</div>
			</div>
		</div>

		<!--footer start-->
		<div class="all-footer">
			<?php include_once('includes/footer.php');?>
		</div>
        <!--footer end-->
	</div>

	<script type="application/x-javascript"> 
		addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } 
	</script>

	<!-- js-->
	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/modernizr.custom.js"></script>

	<!--animate js-->
	<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>

	<!-- Metis Menu js -->
	<script src="js/metisMenu.min.js"></script>
	<script src="js/custom.js"></script>

	<script type="text/javascript">
		function checkpass() {
			if(document.changepassword.newpassword.value!=document.changepassword.confirmpassword.value) {
				alert('New Password and Confirm Password field does not match');

				document.changepassword.confirmpassword.focus();
				return false;
			}

			return true;
		} 
	</script>

	<!-- Classie js -->
	<script src="js/classie.js"></script>
	<script>
		var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
			showLeftPush = document.getElementById( 'showLeftPush' ),
			body = document.body;
				
		showLeftPush.onclick = function() {
			classie.toggle( this, 'active' );
			classie.toggle( body, 'cbp-spmenu-push-toright' );
			classie.toggle( menuLeft, 'cbp-spmenu-open' );
			disableOther( 'showLeftPush' );
		};
			
		function disableOther( button ) {
			if( button !== 'showLeftPush' ) {
				classie.toggle( showLeftPush, 'disabled' );
			}
		}
	</script>

	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>

	<!-- Bootstrap js -->
	<script src="js/bootstrap.js"> </script>
</body>
</html>
<?php } ?>