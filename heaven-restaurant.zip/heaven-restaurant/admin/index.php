<?php
	session_start();
	error_reporting(0);
	include('includes/dbconnection.php');

	if(isset($_POST['login'])) {
		$admin_user=$_POST['username'];
		$password=md5($_POST['password']);

		$query=mysqli_query($con,"select id from admin where  user_name='$admin_user' && admin_password='$password' ");
		$ret=mysqli_fetch_array($query);

		if($ret>0 ){
			$_SESSION['aid']=$ret['id'];
			header('location:dashboard.php');
		} else {
		$msg="Invalid Details.";
		}
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

	<title>Heaven | Admin Login </title>

	<link href="../assets/img/logo.png" rel="icon">

	<!-- Bootstrap CSS -->
	<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />

	<!-- Custom CSS -->
	<link href="css/style.css" rel='stylesheet' type='text/css' />

	<!-- fontawesome css -->
	<link href="css/font-awesome.css" rel="stylesheet"> 

	<!--webfonts css-->
	<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>

	<!--animate css-->
	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">

	<!-- Metis Menu css -->
	<link href="css/custom.css" rel="stylesheet">
</head> 

<body class="cbp-spmenu-push" style="background:url('images/bg1.jpg') no-repeat center fixed;">
	<div class="main-content">
		
		<!-- main content start-->
		<div class="login-main" style="background:url('images/bg1.jpg') no-repeat center fixed;">
			<div class="main-page login-page ">
				<div class="widget-shadow">
					<div class="login-top">
						<h3 class="title1">Admin Login</h3>
						<h4>Welcome To AdminPanel ! </h4>
					</div>

					<div class="login-body">
						<form role="form" method="post" action="" enctype="multipart/form-data">
							<p style="font-size:16px; color:red" align="center"> 
								<?php if($msg) {
									echo $msg;
								}  ?> 
							</p>

							<input type="text" class="user" name="username" placeholder="Username" required>
							<input type="password" name="password" class="lock" placeholder="Password" required>
							<input type="submit" name="login" value="LOGIN">

							<div class="forgot-grid-main">
								<div class="forgot-grid">
									<div class="forgot">
										<a href="../index.php">Back Home</a>
									</div>

									<div class="clearfix"> </div>
								</div>

								<div class="forgot-grid">
									<div class="forgot">
										<a href="forgot-password.php">Forgot Password?</a>
									</div>

									<div class="clearfix"> </div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>

		<!--footer start-->
		<div class="login-footer" style="text-align: center"></div>
			<?php include_once('includes/footer.php');?>
		</div>
        <!--footer end-->
	</div>

	<script type="application/x-javascript"> 
		addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } 
	</script>

	<!-- js-->
	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/modernizr.custom.js"></script>

	<!--animate js-->
	<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>

	<!-- Metis Menu js -->
	<script src="js/metisMenu.min.js"></script>
	<script src="js/custom.js"></script>

	<!-- Classie js -->
	<script src="js/classie.js"></script>
	<script>
		var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
			showLeftPush = document.getElementById( 'showLeftPush' ),
			body = document.body;
				
		showLeftPush.onclick = function() {
			classie.toggle( this, 'active' );
			classie.toggle( body, 'cbp-spmenu-push-toright' );
			classie.toggle( menuLeft, 'cbp-spmenu-open' );
			disableOther( 'showLeftPush' );
		};
			
		function disableOther( button ) {
			if( button !== 'showLeftPush' ) {
				classie.toggle( showLeftPush, 'disabled' );
			}
		}
	</script>

	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>

	<!-- Bootstrap js -->
	<script src="js/bootstrap.js"> </script>
</body>
</html>